package com.example.apssdc.mynews.Widget;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.apssdc.mynews.R;
import static com.example.apssdc.mynews.Widget.NewsAppWidget.articleList;
public class NewsAppWidgetFactory implements RemoteViewsService.RemoteViewsFactory {
    private Context context;
    public NewsAppWidgetFactory(Context applicationContext, Intent intent) {
        this.context=applicationContext;
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDataSetChanged() {

    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        return articleList==null ? 0: articleList.size();
    }

    @Override
    public RemoteViews getViewAt(int position) {
        Log.i("aaaaa", String.valueOf(articleList.size()));

        RemoteViews remoteViews=new RemoteViews(context.getPackageName(),R.layout.widgetlist);
        remoteViews.setTextViewText(R.id.widget_title,articleList.get(position).getTitle());
        //remoteViews.setImageViewResource(R.id.widgetImage, Integer.parseInt(articleList.get(position).getUrlToImage()));
        remoteViews.setTextViewText(R.id.widget_published,articleList.get(position).getAuthor());
        return remoteViews;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }
}

