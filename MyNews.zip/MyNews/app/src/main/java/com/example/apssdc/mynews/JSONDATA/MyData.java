package com.example.apssdc.mynews.JSONDATA;

import com.example.apssdc.mynews.R;

public class MyData {

    public static String[] nameArray={"Business","Entertainment","Health","Science", "Sports","Technology"};
    public static int[] drawableArray={R.drawable.business,
            R.drawable.entertainment,R.drawable.health,
            R.drawable.science,R.drawable.sports,
            R.drawable.technology};

}
