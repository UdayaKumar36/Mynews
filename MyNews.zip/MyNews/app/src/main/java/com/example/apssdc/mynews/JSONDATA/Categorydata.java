package com.example.apssdc.mynews.JSONDATA;

public class Categorydata {

    String categoryname;
    int categoryimage;

    public Categorydata(String categoryname, int categoryimage) {
        this.categoryname = categoryname;
        this.categoryimage = categoryimage;
    }

    public String getCategoryname() {
        return categoryname;
    }

    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    public int getCategoryimage() {
        return categoryimage;
    }

    public void setCategoryimage(int categoryimage) {
        this.categoryimage = categoryimage;
    }
}

