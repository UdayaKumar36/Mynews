package com.example.apssdc.mynews.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.apssdc.mynews.Category;
import com.example.apssdc.mynews.JSONDATA.Categorydata;
import com.example.apssdc.mynews.MainActivity;
import com.example.apssdc.mynews.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {
    private ArrayList<Categorydata> categorydataArrayList;
    Context context;
    String[] countrycode;

    public CategoryAdapter(Category category, ArrayList<Categorydata> categorydata, String[] datum) {
        this.context = category;
        this.categorydataArrayList = categorydata;
        this.countrycode = datum;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.categorylist, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        viewHolder.categoryname.setText(categorydataArrayList.get(i).getCategoryname());
        Picasso.with(context).load(categorydataArrayList.get(i).getCategoryimage()).fit().into(viewHolder.categoryimage);

    }

    @Override
    public int getItemCount() {
        return categorydataArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        @InjectView(R.id.categoryname)
        TextView categoryname;
        @InjectView(R.id.categoryimage)
        ImageView categoryimage;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.inject(this, itemView);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            String[] categoryname = new String[1];
            categoryname[0] = categorydataArrayList.get(getAdapterPosition()).getCategoryname().toLowerCase();
            Intent category = new Intent(context, MainActivity.class);
            category.putExtra("category", categoryname);
            category.putExtra("countrycode", countrycode);
            context.startActivity(category);

        }
    }
}

