package com.example.apssdc.mynews.Roomdatabase;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.apssdc.mynews.JSONDATA.NewsJsonData.Article;

import java.util.List;

@Dao
public interface NewsDAO {
    @Insert
    void insertfav(Article article);

    @Query("SELECT * FROM Favourites")
    LiveData<List<Article>> getArticle();

    @Query("SELECT * FROM Favourites WHERE publishedAt = :unique ")
    public boolean checkfav(String unique);

    @Query("DELETE FROM Favourites")
    public void deleteAll();

    @Delete
    void deletefav(Article article);
}