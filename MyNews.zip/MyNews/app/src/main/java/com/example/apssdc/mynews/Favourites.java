package com.example.apssdc.mynews;

import android.app.AlertDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.apssdc.mynews.Adapter.FavouritesAdapter;
import com.example.apssdc.mynews.Adapter.NewsAdapter;
import com.example.apssdc.mynews.JSONDATA.NewsJsonData.Article;
import com.example.apssdc.mynews.Roomdatabase.DeleteViewModel;
import com.example.apssdc.mynews.Roomdatabase.NewsDataBase;
import com.example.apssdc.mynews.Widget.NewsAppWidget;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class Favourites extends AppCompatActivity {

    @InjectView(R.id.favrecycle)
    RecyclerView favrecyclerView;
    List<Article> articleList;
    private DeleteViewModel deleteViewModel;
    public boolean internet_check = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);
        ButterKnife.inject(this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle(R.string.favourites);

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(this.CONNECTIVITY_SERVICE);

        NetworkInfo MobileNetwork = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        NetworkInfo WifiNetwork = connectivityManager.getNetworkInfo(connectivityManager.TYPE_WIFI);
        internet_check = getIntent().getBooleanExtra("internet_check", false);
        if (MobileNetwork.getState() == NetworkInfo.State.CONNECTED || WifiNetwork.getState() == NetworkInfo.State.CONNECTED) {
            internet_check = true;
        } else {
            internet_check = false;
        }


        favrecyclerView.setLayoutManager(new LinearLayoutManager(this));
        favrecyclerView.setHasFixedSize(true);
        deleteViewModel = ViewModelProviders.of(this).get(DeleteViewModel.class);
        deleteViewModel.getArticlelist().observe(this, new Observer<List<Article>>() {
            @Override
            public void onChanged(@Nullable List<Article> articles) {
                articleList = articles;
                if (articleList.size() != 0) {
                    favrecyclerView.setAdapter(new FavouritesAdapter(Favourites.this, articleList));

                } else {
                    finish();
                }
                NewsAppWidget.sendRefreshBroadcast(getApplicationContext(), articleList);
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.delete, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home && internet_check) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (item.getItemId() == R.id.deleteall) {
            AlertDialog.Builder builder = new AlertDialog.Builder(Favourites.this);
            builder.setTitle(getString(R.string.fav_title)).setMessage(getString(R.string.message_)).
                    setCancelable(false).setPositiveButton(getString(R.string.fav_delete_all),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int id) {
                            deleteViewModel.deleteallarticlelist();
                        }
                    })
                    .setNegativeButton(getString(R.string.fav_cancel), null);
            AlertDialog alert = builder.create();
            alert.setIcon(R.drawable.ic_favorite_black_24dp);
            alert.show();
            return true;
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.message)).
                    setMessage(getString(R.string.enable_internet)).
                    setCancelable(true).setPositiveButton(getString(R.string.retry), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = getIntent();
                    finish();
                    startActivity(intent);
                }
            }).setNegativeButton(getString(R.string.stayhere),null);
            AlertDialog alertDialog = builder.create();
            alertDialog.setCancelable(false);
            alertDialog.show();

        }
        return super.onOptionsItemSelected(item);
    }

}

