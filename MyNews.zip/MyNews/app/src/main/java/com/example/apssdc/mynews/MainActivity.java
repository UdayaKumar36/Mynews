package com.example.apssdc.mynews;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.apssdc.mynews.Adapter.NewsAdapter;
import com.example.apssdc.mynews.JSONDATA.NewsJsonData.Article;
import com.example.apssdc.mynews.Roomdatabase.DeleteViewModel;
import com.example.apssdc.mynews.Roomdatabase.NewsDataBase;
import com.google.firebase.analytics.FirebaseAnalytics;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class MainActivity extends AppCompatActivity {

    Context context;
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    public String url;
    private static final String NEWS_API_KEY = BuildConfig.News_Api_key;
    public ArrayList<Article> newslist = new ArrayList<>();
    List<Article> articleList;
    private ProgressDialog progressDialog;
    TextView category;
    public String[] code, data;
    @InjectView(R.id.newsrecycle)
    RecyclerView recyclerView;
    @InjectView(R.id.swiperefresh)
    SwipeRefreshLayout pullToRefresh;
    private NewsAdapter newsAdapter;
    public NewsDataBase newsDataBase;
    DeleteViewModel deleteViewModel;
    public boolean internet_check = false;
    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        ConnectivityManager connectivityManager = (ConnectivityManager) this
                .getSystemService(this.CONNECTIVITY_SERVICE);
        ButterKnife.inject(this);
        deleteViewModel = ViewModelProviders.of(this).get(DeleteViewModel.class);

        NetworkInfo activeNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo activeNetworkInfo1 = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (activeNetworkInfo.getState() == NetworkInfo.State.CONNECTED || activeNetworkInfo1.getState() == NetworkInfo.State.CONNECTED) {
            internet_check = true;
            mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
            logEvent();
            data = getIntent().getStringArrayExtra("category");
            code = getIntent().getStringArrayExtra("countrycode");
            if (data != null && code != null) {
                setTitle(code[1].toUpperCase() + "-" + data[0].toUpperCase());
                url = "https://newsapi.org/v2/top-headlines?country=" + code[0].toLowerCase() + "&category=" + data[0].toLowerCase() + "&apiKey=" + NEWS_API_KEY;
            } else if (data != null) {
                setTitle("INDIA-" + data[0].toUpperCase());
                url = "https://newsapi.org/v2/top-headlines?country=in&category=" + data[0].toLowerCase() + "&apiKey=" + NEWS_API_KEY;
            } else {
                setTitle("INDIA-BUSINESS");
                url = "https://newsapi.org/v2/top-headlines?country=in&category=business&apiKey=" + NEWS_API_KEY;
            }
            recyclerView.setLayoutManager(new LinearLayoutManager(context));

            if (savedInstanceState != null) {
                newslist = savedInstanceState.getParcelableArrayList("newslist");
                newsAdapter = new NewsAdapter(MainActivity.this, newslist);
                recyclerView.setAdapter(newsAdapter);
            } else {
                progressDialog = new ProgressDialog(this);
                progressDialog.setTitle(getString(R.string.receiving_news));
                progressDialog.setMessage(getString(R.string.loading__));
                progressDialog.setProgressStyle(progressDialog.STYLE_SPINNER);
                progressDialog.setCanceledOnTouchOutside(false);
                progressDialog.show();

                newsDataBase = Room.databaseBuilder(this, NewsDataBase.class,
                        getString(R.string.newsdb)).allowMainThreadQueries().build();
                Newsdata();

                pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        newsAdapter = new NewsAdapter(MainActivity.this, newslist);
                        recyclerView.setAdapter(newsAdapter);
                        pullToRefresh.setRefreshing(false);
                    }
                });
                RecyclerView.ItemDecoration itemDecoration = new
                        DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
                recyclerView.addItemDecoration(itemDecoration);
                recyclerView.setHasFixedSize(true);
            }


        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.message)).setMessage(getString(R.string.main_message)).
                    setCancelable(false).setPositiveButton(getString(R.string.retry),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int id) {

                            Intent intent = getIntent();
                            finish();
                            startActivity(intent);
                        }
                    }).setNegativeButton("Go To Favourites", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    internet_check = false;
                    Intent favourite = new Intent(MainActivity.this, Favourites.class);
                    favourite.putExtra("internet_check", internet_check);
                    startActivity(favourite);
                }
            });
            AlertDialog alert = builder.create();
            alert.setIcon(R.drawable.newslogo);
            alert.show();
        }

    }

    private void logEvent() {
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, "News click");
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "News Name");
        bundle.putString(FirebaseAnalytics.Param.CONTENT_TYPE, "text");
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);
    }

    private void Newsdata() {
        requestQueue = Volley.newRequestQueue(this);
        stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("articles");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        Article article = new Article();


                        String image = jsonObject1.getString("urlToImage");
                        String title = jsonObject1.getString("title");
                        String author = jsonObject1.getString("author");
                        String description = jsonObject1.getString("description");
                        String url = jsonObject1.getString("url");
                        String publisheddate = jsonObject1.getString("publishedAt");
                        String content = jsonObject1.getString("content");

                        article.setUrlToImage(image);
                        article.setTitle(title);
                        article.setAuthor(author);
                        article.setDescription(description);
                        article.setUrl(url);
                        article.setPublishedAt(publisheddate);
                        article.setContent(content);

                        newslist.add(article);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (newslist.size() != 0) {
                    recyclerView.setAdapter(new NewsAdapter(MainActivity.this, newslist));
                    progressDialog.dismiss();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle(getString(R.string.country_title)).setMessage(getString(R.string.county_message)).
                            setCancelable(false).setPositiveButton(getString(R.string.retry),
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,
                                                    int id) {

                                    Intent intent = new Intent(MainActivity.this, Country.class);
                                    startActivity(intent);
                                }
                            })
                            .setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                                    startActivity(intent);
                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.setIcon(R.drawable.news);
                    alert.show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error", error.toString());
                progressDialog.dismiss();
            }
        });
        requestQueue.add(stringRequest);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.design, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_sort:
                showSortMenu();
                return true;

            case R.id.favourite:

                deleteViewModel.getArticlelist().observe(this, new Observer<List<Article>>() {
                    @Override
                    public void onChanged(@Nullable List<Article> articles) {
                        articleList = articles;
                        if (articles.size() != 0) {
                            Intent favourites = new Intent(MainActivity.this, Favourites.class);
                            startActivity(favourites);

                        } else {
                            final Snackbar snackbar = Snackbar.make(getWindow().getDecorView(), R.string.snack_text, Snackbar.LENGTH_INDEFINITE);
                            snackbar.setAction(R.string.snack_ok, new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    snackbar.dismiss();
                                }
                            });
                            snackbar.show();
                            View snackbarview = snackbar.getView();
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                snackbarview.setBackgroundColor(getColor(R.color.snackbar));
                            }

                            TextView textView = snackbarview.findViewById(android.support.design.R.id.snackbar_text);
                            textView.setAllCaps(true);
                            textView.setTextSize(13);

                        }

                    }
                });

        }
        return super.onOptionsItemSelected(item);
    }

    private void showSortMenu() {
        PopupMenu sortMenu = new PopupMenu(this, findViewById(R.id.action_sort));
        sortMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @SuppressLint("NewApi")
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.country:
                        Intent country = new Intent(MainActivity.this, Country.class);
                        startActivity(country);
                        return true;

                    case R.id.category:
                        Intent category = new Intent(MainActivity.this, Category.class);
                        category.putExtra("countrycode", code);
                        startActivity(category);
                        return true;

                    default:
                        return false;
                }
            }
        });
        sortMenu.inflate(R.menu.sortby);
        sortMenu.show();
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    public void onSaveInstanceState(Bundle outstate) {
        super.onSaveInstanceState(outstate);
        outstate.putParcelableArrayList("newslist", newslist);
    }


}

