package com.example.apssdc.mynews;

import android.app.AlertDialog;
import android.app.LoaderManager;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.AsyncTaskLoader;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.apssdc.mynews.Adapter.CountryAdapter;
import com.example.apssdc.mynews.JSONDATA.Countrydata;
import com.example.apssdc.mynews.JSONDATA.ParseCountryJson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class Country extends AppCompatActivity implements CountryAdapter.CountryAdapterListener,LoaderManager.LoaderCallbacks {


    Context context;
    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    String country_url = "https://countryapi.gear.host/v1/Country/getCountries";
    public ArrayList<Countrydata> countrylist = new ArrayList<>();
    ProgressDialog progressDialog;
    @InjectView(R.id.countryrecycle)
    RecyclerView recycle;
    private CountryAdapter countryAdapter;
    public List<Countrydata> countrydataList;
    private SearchView searchView;

    public void setContext(Context context) {
        this.context = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country);
        ButterKnife.inject(this);

        ConnectivityManager connectivityManager = (ConnectivityManager) this
                .getSystemService(this.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetworkInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo activeNetworkInfo1 = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (activeNetworkInfo.getState() == NetworkInfo.State.CONNECTED || activeNetworkInfo1.getState() == NetworkInfo.State.CONNECTED) {
            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle(getString(R.string.grasping_countries));
            progressDialog.setMessage(getString(R.string.loading));
            progressDialog.setProgressStyle(progressDialog.STYLE_SPINNER);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();


            setTitle(R.string.country_names);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);


            getLoaderManager().initLoader(3, null, this);
            recycle.setLayoutManager(new GridLayoutManager(context, 2));

            RecyclerView.ItemDecoration itemDecoration = new
                    DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
            recycle.addItemDecoration(itemDecoration);
            recycle.setHasFixedSize(true);

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(getString(R.string.message)).setCancelable(false).setPositiveButton(getString(R.string.retry),
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int id) {

                            Intent intent = getIntent();
                            finish();
                            startActivity(intent);
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.search, menu);

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.action_search)
                .getActionView();
        searchView.setQueryHint(getString(R.string.search_hint));
        searchView.setSearchableInfo(searchManager
                .getSearchableInfo(getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // filter recycler view when query submitted
                countryAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                // filter recycler view when text is changed
                countryAdapter.getFilter().filter(query);
                return false;
            }
        });
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.action_search) {
            return true;
        }

        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (!searchView.isIconified()) {
            searchView.setIconified(true);
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void onCountrySelected(Countrydata countrydata) {

    }

    @Override
    public Loader onCreateLoader(int id, Bundle args) {
        return new AsyncTaskLoader(this) {


            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                forceLoad();
            }

            @Override
            public Object loadInBackground() {
                StringBuilder stringBuilder = new StringBuilder();

                try {
                    URL url = new URL(country_url);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.connect();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    String sentence = " ";
                    while ((sentence = bufferedReader.readLine()) != null) {
                        stringBuilder.append(sentence);
                    }

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return stringBuilder.toString();
            }
        };
    }

    @Override
    public void onLoadFinished(Loader loader, Object data) {
        progressDialog.dismiss();
        countrydataList = ParseCountryJson.getCountrydata(data.toString());
        countryAdapter = new CountryAdapter(Country.this, countrydataList, Country.this);
        recycle.setAdapter(countryAdapter);

    }

    @Override
    public void onLoaderReset(Loader loader) {

    }
}

