package com.example.apssdc.mynews;

import android.app.AlertDialog;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.transition.TransitionInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.apssdc.mynews.JSONDATA.NewsJsonData.Article;
import com.example.apssdc.mynews.Roomdatabase.DeleteViewModel;
import com.example.apssdc.mynews.Roomdatabase.NewsDataBase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.squareup.picasso.Picasso;

import java.io.File;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class Newsdetails extends AppCompatActivity {

    @InjectView(R.id.toolbar)
    Toolbar toolbar;
    @InjectView(R.id.detailimage)
    ImageView detailimage;
    @InjectView(R.id.author)
    TextView author;
    @InjectView(R.id.date)
    TextView date;
    @InjectView(R.id.time)
    TextView time;
    @InjectView(R.id.description)
    TextView description;
    @InjectView(R.id.url)
    TextView url;
    @InjectView(R.id.content)
    TextView content;
    @InjectView(R.id.favourites)
    LikeButton likeButton;
    public String publishedAt;
    private int id = 0;
    NewsDataBase newsDataBase;
    DeleteViewModel deleteViewModel;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newsdetails);

        ButterKnife.inject(this);

        databaseReference = FirebaseDatabase.getInstance().getReference("feedback");

        final Article article = getIntent().getParcelableExtra("newsdetail");
        newsDataBase = Room.databaseBuilder(this, NewsDataBase.class,
                getString(R.string.newsdb)).allowMainThreadQueries().build();

        deleteViewModel = ViewModelProviders.of(this).get(DeleteViewModel.class);

        toolbar.setTitle(article.getTitle());
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Picasso.with(this).load(article.getUrlToImage()).placeholder(R.drawable.news).
                error(R.drawable.noimage).fit().into(detailimage);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setSharedElementEnterTransition(TransitionInflater.from(this).inflateTransition(R.transition.shared_element_transation));
            detailimage.setTransitionName(getString(R.string.profile));
        }


        if (!article.getAuthor().equals("null")) {
            author.setText(article.getAuthor());
        } else {
            author.setText(getString(R.string.no_author));
        }

        publishedAt = article.getPublishedAt();
        String[] DateTime = publishedAt.split(getString(R.string.t));
        date.setText(DateTime[0]);
        time.setText(DateTime[1]);

        if (!article.getDescription().equals("null")) {
            description.setText(article.getDescription());
            description.setTextIsSelectable(true);
        } else {
            description.setText(getString(R.string.no_description));
        }

        if (!article.getContent().equals("null")) {
            content.setText(article.getContent());
            content.setTextIsSelectable(true);
        } else {
            content.setText(getString(R.string.no_content));
        }

        url.setText("'" + article.getUrl() + "'");

        if (newsDataBase.newsDAO().checkfav(article.getPublishedAt())) {
            likeButton.setLiked(true);
        }

        likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                Article article = getIntent().getParcelableExtra("newsdetail");
                article.getTitle();
                article.getUrlToImage();
                article.getAuthor();
                article.getPublishedAt();
                article.getDescription();
                article.getContent();
                article.getUrl();
                id += 1;
                article.setId(id);
                deleteViewModel.setArticlelist(article);
            }

            @Override
            public void unLiked(final LikeButton likeButton) {

                AlertDialog.Builder builder = new AlertDialog.Builder(Newsdetails.this);
                builder.setTitle(getString(R.string.remove_fav)).setMessage(getString(R.string.delete_fav)).
                        setCancelable(false).setPositiveButton(getString(R.string.ok),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int id) {

                                Article article = getIntent().getParcelableExtra("newsdetail");
                                article.getTitle();
                                article.getUrlToImage();
                                article.getAuthor();
                                article.getPublishedAt();
                                article.getDescription();
                                article.getContent();
                                article.getUrl();
                                id = article.getId();
                                article.setId(id);
                                deleteViewModel.deletearticlelist(article);
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                likeButton.setLiked(true);
                            }
                        });
                AlertDialog alert = builder.create();
                alert.setIcon(R.drawable.ic_favorite_black_24dp);
                alert.show();
            }
        });

        url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Article article = getIntent().getParcelableExtra("newsdetail");
                Uri uri = Uri.parse(article.getUrl());
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent share = new Intent();
                share.setAction(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, getString(R.string.title) + article.getTitle() + "\n" + getString(R.string.url) + article.getUrl());
                share.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                startActivity(Intent.createChooser(share, getString(R.string.share_title)));
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            ActivityCompat.finishAfterTransition(this);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        ActivityCompat.finishAfterTransition(this);
    }

    public void feedbacktaken(View view) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.feedbacktitle));
        builder.setMessage(getString(R.string.feedback_message));

        final EditText input = new EditText(this);
        input.setHint(getString(R.string.feedback_hint));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        input.setLayoutParams(lp);
        builder.setView(input);
        builder.setPositiveButton(getString(R.string.feedback_submit), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String feed = input.getText().toString();
                String id = databaseReference.push().getKey();
                databaseReference.child(id).setValue(feed);
                Toast.makeText(getApplicationContext(), "Text entered is " + input.getText().toString(), Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton(getString(R.string.cancel_feedback), null);
        builder.setCancelable(false);
        builder.show();
    }
}
