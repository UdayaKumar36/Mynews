package com.example.apssdc.mynews;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

import com.example.apssdc.mynews.Adapter.CategoryAdapter;
import com.example.apssdc.mynews.JSONDATA.Categorydata;
import com.example.apssdc.mynews.JSONDATA.MyData;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class Category extends AppCompatActivity {


    @InjectView(R.id.crecycle)
    RecyclerView recyclerView;
    String[] code, countrydetails;
    private static ArrayList<Categorydata> categorydata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        ButterKnife.inject(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle(R.string.category);

        countrydetails = getIntent().getStringArrayExtra("country");
        code = getIntent().getStringArrayExtra("countrycode");

        categorydata = new ArrayList<>();
        for (int i = 0; i < MyData.nameArray.length; i++) {
            categorydata.add(new Categorydata(
                    MyData.nameArray[i],
                    MyData.drawableArray[i]
            ));
        }
        if (countrydetails != null) {
            recyclerView.setAdapter(new CategoryAdapter(this, categorydata, countrydetails));
        } else {
            recyclerView.setAdapter(new CategoryAdapter(this, categorydata, code));
        }

        RecyclerView.ItemDecoration itemDecoration = new
                DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(itemDecoration);
        recyclerView.setHasFixedSize(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}
