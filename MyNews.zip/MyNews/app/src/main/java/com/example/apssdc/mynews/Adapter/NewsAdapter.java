package com.example.apssdc.mynews.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.apssdc.mynews.JSONDATA.NewsJsonData.Article;
import com.example.apssdc.mynews.MainActivity;
import com.example.apssdc.mynews.Newsdetails;
import com.example.apssdc.mynews.R;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.Optional;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {
    Context context;
    List<Article> articleList;


    public NewsAdapter(MainActivity mainActivity, ArrayList<Article> newslist) {
        this.context = mainActivity;
        this.articleList = newslist;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.newslist, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {
        Picasso.with(context).load(articleList.get(i).getUrlToImage()).placeholder(R.drawable.news).
                error(R.drawable.noimage).fit().into(viewHolder.newsimage);
        viewHolder.newsTitle.setText(articleList.get(i).getTitle());
    }

    @Override
    public int getItemCount() {
        if (articleList != null) {
            return articleList.size();
        } else {
            return 1;
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        @InjectView(R.id.newsimage)
        ImageView newsimage;
        @InjectView(R.id.newstitle)
        TextView newsTitle;
        @Optional
        @InjectView(R.id.cardview)
        CardView cardView;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.inject(this, itemView);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            String transaction_name = context.getString(R.string.transaction_name);
            Intent newsdetail = new Intent(context, Newsdetails.class);
            newsdetail.putExtra("newsdetail", articleList.get(getAdapterPosition()));
            ActivityOptionsCompat options = ActivityOptionsCompat.
                    makeSceneTransitionAnimation((Activity) context, newsimage, transaction_name);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                context.startActivity(newsdetail, options.toBundle());
            }
        }
    }
}

