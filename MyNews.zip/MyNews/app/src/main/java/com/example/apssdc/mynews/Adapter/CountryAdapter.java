package com.example.apssdc.mynews.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.apssdc.mynews.Category;
import com.example.apssdc.mynews.Country;
import com.example.apssdc.mynews.JSONDATA.Countrydata;
import com.example.apssdc.mynews.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class CountryAdapter extends RecyclerView.Adapter<CountryAdapter.ViewHolder> implements Filterable {
    Context context;
    private List<Countrydata> countrydataList;
    private List<Countrydata> countrylistfiltered;
    private int lastselected = -1;
    private CountryAdapterListener listener;

    public CountryAdapter(Country country, List countrydataList, CountryAdapterListener listener) {
        this.context = country;
        this.countrydataList = countrydataList;
        this.countrylistfiltered = countrydataList;
        this.listener = listener;
    }


    public interface CountryAdapterListener {
        void onCountrySelected(Countrydata countrydata);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.countrylist, viewGroup, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CountryAdapter.ViewHolder viewHolder, int i) {

        final Countrydata countrydata = countrylistfiltered.get(i);
        viewHolder.countryname.setText(countrydata.getName());
        Picasso.with(context).load(countrydata.getFlag()).placeholder(R.drawable.news).
                error(R.drawable.noimage).into(viewHolder.countryimage);

        if (i == lastselected) {
            viewHolder.countrylayout.setSelected(true);
            viewHolder.countryname.setTextColor(Color.parseColor("#56b5a8"));
        } else {
            viewHolder.countrylayout.setSelected(false);
            viewHolder.countryname.setTextColor(Color.parseColor("#000000"));
        }

    }

    @Override
    public int getItemCount() {
        return countrylistfiltered.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        @InjectView(R.id.cimage)
        ImageView countryimage;
        @InjectView(R.id.cname)
        TextView countryname;
        @InjectView(R.id.countrylayout)
        LinearLayout countrylayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.inject(this, itemView);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            lastselected = getAdapterPosition();
            String[] countrydetails = new String[3];
            listener.onCountrySelected(countrylistfiltered.get(getAdapterPosition()));
            countrydetails[0] = countrylistfiltered.get(lastselected).getAlpha2Code().toLowerCase();
            countrydetails[1] = countrylistfiltered.get(lastselected).getName();
            countrydetails[2] = countrylistfiltered.get(lastselected).getFlag();
            Intent country = new Intent(context, Category.class);
            country.putExtra("country", countrydetails);
            context.startActivity(country);
            notifyDataSetChanged();

        }
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    countrylistfiltered = countrydataList;
                } else {
                    List<Countrydata> filteredList = new ArrayList<>();
                    for (Countrydata row : countrydataList) {

                        if (row.getName().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }
                    countrylistfiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = countrylistfiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                countrylistfiltered = (ArrayList<Countrydata>) results.values;
                notifyDataSetChanged();
            }

        };
    }

}

