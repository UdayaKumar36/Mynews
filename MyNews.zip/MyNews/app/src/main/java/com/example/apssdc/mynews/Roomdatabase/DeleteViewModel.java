package com.example.apssdc.mynews.Roomdatabase;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.support.annotation.NonNull;

import com.example.apssdc.mynews.JSONDATA.NewsJsonData.Article;

import java.util.List;

public class DeleteViewModel extends AndroidViewModel {

    private LiveData<List<Article>> articlelist;
    private RepositoryClass newsrepository;

    public DeleteViewModel(@NonNull Application application) {
        super(application);
        newsrepository=new RepositoryClass(application);
        articlelist=newsrepository.getdatalive();
    }


    public LiveData<List<Article>> getArticlelist()
    {
        return articlelist;
    }

    public void setArticlelist(Article articlelist)
    {
        newsrepository.insertArticle(articlelist);
    }

    public void deletearticlelist(Article article)
    {
        newsrepository.deleteArticle(article);
    }


    public void deleteallarticlelist()
    {
        newsrepository.deleteallArticle();
    }
}

