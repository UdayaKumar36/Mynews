package com.example.apssdc.mynews.Widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v4.app.TaskStackBuilder;
import android.widget.RemoteViews;

import com.example.apssdc.mynews.Favourites;
import com.example.apssdc.mynews.JSONDATA.NewsJsonData.Article;
import com.example.apssdc.mynews.R;

import java.util.ArrayList;
import java.util.List;

public class NewsAppWidget extends AppWidgetProvider {

    public static List<Article> articleList;

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of them
        for (int appWidgetId : appWidgetIds) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.new_app_widget);

            // click event handler for the title, launches the app when the user clicks on title
            Intent titleIntent = new Intent(context, Favourites.class);
            PendingIntent titlePendingIntent = PendingIntent.getActivity(context, 0, titleIntent, 0);
            views.setOnClickPendingIntent(R.id.appwidget_text, titlePendingIntent);


            Intent intent = new Intent(context, NewsAppWidgetService.class);
            if (articleList== null) {
                views.setRemoteAdapter(R.id.favlist, intent);
            } else {
                views.setTextViewText(R.id.widget_emptyView, "No Favourites");
            }


            // template to handle the click listener for each item
            Intent clickIntentTemplate = new Intent(context, Favourites.class);
            PendingIntent clickPendingIntentTemplate = TaskStackBuilder.create(context)
                    .addNextIntentWithParentStack(clickIntentTemplate)
                    .getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
            views.setPendingIntentTemplate(R.id.favlist, clickPendingIntentTemplate);

            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }

    public static void sendRefreshBroadcast(Context context, List<Article> list) {
        Intent intent = new Intent(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        intent.setComponent(new ComponentName(context, NewsAppWidget.class));
        articleList = list;
        intent.putParcelableArrayListExtra("a", (ArrayList<? extends Parcelable>) articleList);
        context.sendBroadcast(intent);
    }

    @Override
    public void onReceive(final Context context, Intent intent) {
        final String action = intent.getAction();
        if (action.equals(AppWidgetManager.ACTION_APPWIDGET_UPDATE)) {
            // refresh all your widgets
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            ComponentName componentName = new ComponentName(context, NewsAppWidget.class);
            articleList = intent.getParcelableArrayListExtra("a");
            appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetManager.getAppWidgetIds(componentName), R.id.favlist);
        }
        super.onReceive(context, intent);
    }
}


