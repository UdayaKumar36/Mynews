package com.example.apssdc.mynews.JSONDATA;

import com.example.apssdc.mynews.Adapter.CountryAdapter;
import com.example.apssdc.mynews.Country;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ParseCountryJson {

    static List<Countrydata> countrydataList;

    public static List<Countrydata> getCountrydata(String s) {
        countrydataList = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(s);

            JSONArray jsonArray = jsonObject.getJSONArray("Response");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                Countrydata countrydata = new Countrydata();

                String countryname = jsonObject1.getString("Name");
                String countrycode = jsonObject1.getString("Alpha2Code");
                String countryflag = jsonObject1.getString("FlagPng");

                countrydata.setName(countryname);
                countrydata.setAlpha2Code(countrycode.toLowerCase());
                countrydata.setFlag(countryflag);

                countrydataList.add(countrydata);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return countrydataList;
    }
}
