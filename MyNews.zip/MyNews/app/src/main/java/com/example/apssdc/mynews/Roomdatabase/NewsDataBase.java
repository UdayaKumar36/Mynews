package com.example.apssdc.mynews.Roomdatabase;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.example.apssdc.mynews.JSONDATA.NewsJsonData.Article;

@Database(entities = {Article.class}, version = 2, exportSchema = false)
public abstract class NewsDataBase extends RoomDatabase {

    private static NewsDataBase INSTANCE;

    public static NewsDataBase getDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(), NewsDataBase.class, "newsdb.db")
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();

        }
        return INSTANCE;

    }

    public abstract NewsDAO newsDAO();
}
