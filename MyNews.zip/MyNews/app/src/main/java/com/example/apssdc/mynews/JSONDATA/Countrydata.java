package com.example.apssdc.mynews.JSONDATA;

import android.os.Parcel;
import android.os.Parcelable;

public class Countrydata implements Parcelable {

    private String name;
    private String flag;
    private String alpha2Code;


    public Countrydata(Parcel in) {
        name = in.readString();
        flag = in.readString();
        alpha2Code = in.readString();
    }

    public static final Creator<Countrydata> CREATOR = new Creator<Countrydata>() {
        @Override
        public Countrydata createFromParcel(Parcel in) {
            return new Countrydata(in);
        }

        @Override
        public Countrydata[] newArray(int size) {
            return new Countrydata[size];
        }
    };

    public Countrydata() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getAlpha2Code() {
        return alpha2Code;
    }

    public void setAlpha2Code(String alpha2Code) {
        this.alpha2Code = alpha2Code;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(flag);
        dest.writeString(alpha2Code);
    }
}
