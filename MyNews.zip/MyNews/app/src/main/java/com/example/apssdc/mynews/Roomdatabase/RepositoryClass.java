package com.example.apssdc.mynews.Roomdatabase;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import com.example.apssdc.mynews.JSONDATA.NewsJsonData.Article;

import java.util.List;

public class RepositoryClass {


    private NewsDAO newsDAO;
    private LiveData<List<Article>> getarticle;

    public RepositoryClass(Application application) {

        NewsDataBase dataBase = NewsDataBase.getDatabase(application);
        newsDAO = dataBase.newsDAO();
        getarticle = newsDAO.getArticle();
    }

    public LiveData<List<Article>> getdatalive() {
        return getarticle;
    }


    public void insertArticle(Article article) {
        new InsertArticleAsync(newsDAO).execute(article);
    }


    private class InsertArticleAsync extends AsyncTask<Article, Void, Void> {

        NewsDAO newsDAO;

        public InsertArticleAsync(NewsDAO newsDAO) {
            this.newsDAO = newsDAO;
        }

        @Override
        protected Void doInBackground(Article... articles) {

            newsDAO.insertfav(articles[0]);
            return null;
        }
    }

    public void deleteArticle(Article article) {
        new DeleteArticleAsync(newsDAO).execute(article);
    }

    private class DeleteArticleAsync extends AsyncTask<Article, Void, Void> {

        NewsDAO dao;

        public DeleteArticleAsync(NewsDAO newsDAO) {
            this.dao = newsDAO;
        }

        @Override
        protected Void doInBackground(Article... articles) {

            dao.deletefav(articles[0]);
            return null;
        }
    }


    public void deleteallArticle() {
        new DeleteallArticleAsync(newsDAO).execute();
    }

    private class DeleteallArticleAsync extends AsyncTask<Void, Void, Void> {

        NewsDAO dao;

        public DeleteallArticleAsync(NewsDAO newsDAO) {
            this.dao = newsDAO;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            dao.deleteAll();
            return null;
        }
    }
}
